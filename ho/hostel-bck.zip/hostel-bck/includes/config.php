<?php
$dbuser="root";
$dbpass="MSkrishna@14";
$host="localhost";
$db="bindun";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
$conn = $mysqli;
?>
<?php
$dbuser="audiobus_zeroin";
$dbpass="b66W6R@L25";
$host="localhost";
$db="audiobus_zeroin";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>
<nav class="ts-sidebar">
    <ul class="ts-sidebar-menu">
    
        <li class="ts-label">Main</li>
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>

        <li><a href="registration.php"><i class="fa fa-user"></i> Registration</a></li>
        <li><a href="manage-users.php"><i class="fa fa-users"></i> Manage </a></li>

        <li><a href="#"><i class="fa fa-files-o"></i> POST</a>
            <ul>
                <li><a href="new-posts.php">New</a></li>
               
                <li><a href="closed-posts.php">Closed</a></li>
                <li><a href="all-posts.php">All</a></li>
            </ul>
        </li>

        <li><a href="#"><i class="fa fa-desktop"></i> Feedback</a>
            <ul>
                <li><a href="#">All Feedbacks</a></li>
                <!-- <li><a href="feedback-report.php">Feedbacks Report</a></li> -->
            </ul>
        </li>

        <li><a href="access-log.php"><i class="fa fa-file"></i> User Access Logs</a></li>

    </ul>
</nav>
